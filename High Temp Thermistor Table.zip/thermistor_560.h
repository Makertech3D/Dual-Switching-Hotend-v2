/**
 * Marlin 3D Printer Firmware
 * Copyright (c) 2020 MarlinFirmware [https://github.com/MarlinFirmware/Marlin]
 *
 * Based on Sprinter and grbl.
 * Copyright (c) 2011 Camiel Gubbels / Erik van der Zalm
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
#pragma once

// High Temp. Thermistor
constexpr temp_entry_t temptable_560[] PROGMEM = {
  { OV(  17.5), 850 },
  { OV(  17.9), 500 },
  { OV(  20.0), 480 },
  { OV(  25.0), 450 },
  { OV(  32.0), 420 }, 
  { OV(  38.8), 397 },
  { OV(  48.5), 375 },
  { OV(  65.0), 343 },
  { OV(  92.0), 320 },  
  { OV( 129.0), 288 },
  { OV( 174.0), 276 },
  { OV( 245.0), 255 },
  { OV( 326.0), 226 },
  { OV( 443.0), 205 },
  { OV( 570.0), 186 },
  { OV( 705.0), 157 },
  { OV( 810.0), 140 },
  { OV( 965.0), 101 },
  { OV( 992.5),  86 },
  { OV(  1008),  65 },
  { OV(1019.5),  40 },
  { OV(  1021),  22 },
  { OV(  1022),  15 },
  { OV(  1023),  10 }

  //https://www.desmos.com/calculator/zb6hnl2phb


};
